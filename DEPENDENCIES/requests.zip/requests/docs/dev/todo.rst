How to Help
===========

Requests is under active development, and contributions are more than welcome!


What Needs to be Done
---------------------

- OAuth Support (`#65 <https://github.com/kennethreitz/requests/issues/65>`_)
- HTTP Cert Checking (`#30 <https://github.com/kennethreitz/requests/issues/30>`_)
- Removal of Poster (`#68 <https://github.com/kennethreitz/requests/issues/68>`_)
- Python 3.x Support (`#70 <https://github.com/kennethreitz/requests/issues/70>`_)
- Kerberos Support (`#47 <https://github.com/kennethreitz/requests/issues/47>`_)
- More Flexible Context Manager (`#69 <https://github.com/kennethreitz/requests/issues/69>`_)